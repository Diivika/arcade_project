<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="farm_textures" tilewidth="18" tileheight="18" spacing="1" tilecount="112" columns="16">
 <image source="Tilemap/tilemap2.png" width="303" height="132"/>
</tileset>
