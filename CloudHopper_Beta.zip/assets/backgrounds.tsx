<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="backgrounds" tilewidth="18" tileheight="18" spacing="2" tilecount="27" columns="9">
 <image source="Tilemap/tilemap-backgrounds_packed.png" width="192" height="72"/>
</tileset>
