<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="blocks" tilewidth="18" tileheight="18" spacing="1" tilecount="180" columns="20">
 <image source="Tilemap/tilemap.png" width="379" height="170"/>
</tileset>
